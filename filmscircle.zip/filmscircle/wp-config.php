<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'filmscircle');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'I~7fYJ)UUCm=hQ-TJ)SwM7?Py!.([2;Fl>u^a:j2M]SV56Vh<5{fB?8ti?3.~M}i');
define('SECURE_AUTH_KEY',  '^r_ZNz!D0AFLzzefMN)OCj9j8#=7[l_uh98+)KBu~YugZFMHqZ55(q7zC4%]+,G$');
define('LOGGED_IN_KEY',    'b:5tp(maG `w*r.Z,9k_<?+xvCPc9$ p><hQ|zRTuZ^yi0-Tp~EyKbFU!l]_5n:!');
define('NONCE_KEY',        'z%>JgU`K2L{yFTe<p$IX1QD1CN(L3 kssFKLSI?)A[X8<B9%l0nQXbsae@mgL~u2');
define('AUTH_SALT',        'tS`J/(/.?ya!kx~(3+1s@FcWp@mteLsUCON`Vrj3<){*KCPQJN{[gS|7^&UJ{a2Z');
define('SECURE_AUTH_SALT', 'Yt$Vj,zPwnBgcXWRz1~Hbam/Pet-8?U<-;rdV>CKH&W<<&T|+me 9[A+1D+u5Gz1');
define('LOGGED_IN_SALT',   '@8(e#-|YBhxn8%J*Q:OtW!JoVwyk,7GR%Ek,m14m0()8Sq0hc39QN&WjP0.HS9jF');
define('NONCE_SALT',       '+ay((u-qenO65Gfs{E$Q8(4Ld9H}2%QMTBNj6p}IN7q^rZ?&2*f_84!5Ql+/B>zH');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
